# Lumio (work in progress)
Single-file app: open lumio.html in a browser. Data is stored in this browser only (localStorage).
Built: themes, adaptive classes, schedule + lesson locks, quizzes, XP/streaks/achievements, revision + mock tests,
goals/exam countdown, complementary session, Spaceship sim, Coding lab (JS), Chemistry, AI, Web, Genetics, Modelling, Budget, Number Hop.
Also built: flashcards, key points and checklists per chapter, guardian summary (consent, device-only), leaderboard privacy, history timeline, glossary, capitals game, school-hours and dinner aware scheduler.
Not built: official syllabus content, uploads, Python sandbox, parent dashboard, real leaderboard, worksheets, accounts/server, reminders.
Chapter/question content is sample material, not official curriculum.
